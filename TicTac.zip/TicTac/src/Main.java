
public class Main 
{
	public static void main(String args[])
	{
		@SuppressWarnings("unused")
		TicTacToe tictactoe = new TicTacToe();
	}

}
